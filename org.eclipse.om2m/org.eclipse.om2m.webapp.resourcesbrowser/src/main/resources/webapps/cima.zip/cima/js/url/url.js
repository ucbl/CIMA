/* URL declaration */
var URL_DEVICE_CONTEXT = '/om2m/nscl/applications/CIMA/administration/device/context';
var URL_DEVICE_CAPABILITY = '/om2m/nscl/applications/CIMA/administration/device/capability';
var URL_PROFILE = '/om2m/nscl/applications/CIMA/administration/profile';
var URL_PROFILE_MATCHING = '/om2m/nscl/applications/CIMA/administration/profileMatching';
var URL_LOGIN = '/om2m/nscl/applications/CIMA/administration/login';
var URL_DEVICE = '/om2m/nscl/applications/CIMA/administration/device';
//var URL_DEVICE = 'json/newformatdevices.json';
//var URL_DEVICE = 'json/goodjson.json';
//var URL_DEVICE = 'http://localhost:4040/angular-project/api/';
//var URL_PROTOCOLS = '/om2m/nscl/applications/CIMA/administration/protocol';
var URL_PROTOCOLS = 'json/protocols.json';

var URL_CAPABILITIES = 'json/capabilities.json';
//var URL_CAPABILITIES= '/om2m/nscl/applications/CIMA/administration/capabilities';

var DEVICE_REFRESH = 5000;
